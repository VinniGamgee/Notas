# Notas (estilo Xiaomi) — Kotlin + Jetpack Compose

Bloco de notas com pastas, fixar no topo, cores, listas de tarefas, lixeira, busca e modo escuro.

## Gerar o APK

**Opção 1 — GitHub (sem instalar nada):** suba esta pasta num repositório. Em *Actions → Build APK → Run workflow* (ou a cada push) o APK aparece em *Artifacts* (`Notas-debug-apk`).

**Opção 2 — Android Studio:** *File → Open* nesta pasta, espere o sync e use *Build → Build APK(s)*. O arquivo fica em `app/build/outputs/apk/debug/app-debug.apk`.

O APK é de debug (assinado com a chave de debug) e instala direto no celular com "instalar apps desconhecidos" liberado.
