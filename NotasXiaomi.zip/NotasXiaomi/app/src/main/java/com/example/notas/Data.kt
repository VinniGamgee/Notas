package com.example.notas

import android.app.Application
import android.content.Context
import android.os.Handler
import android.os.Looper
import androidx.compose.runtime.mutableStateListOf
import androidx.lifecycle.AndroidViewModel
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

val FOLDERS = listOf("Sem pasta", "Pessoal", "Trabalho", "Ideias")

/** check: 0 = texto simples, 1 = tarefa pendente, 2 = tarefa concluída */
data class Line(val text: String = "", val check: Int = 0)

data class Note(
    val id: String = UUID.randomUUID().toString(),
    val title: String = "",
    val lines: List<Line> = listOf(Line()),
    val color: Int = 0,
    val folder: Int = 0,
    val pinned: Boolean = false,
    val deleted: Boolean = false,
    val updated: Long = System.currentTimeMillis(),
)

private fun Note.toJson(): JSONObject {
    val ls = JSONArray()
    lines.forEach { ls.put(JSONObject().put("x", it.text).put("c", it.check)) }
    return JSONObject()
        .put("id", id).put("t", title).put("l", ls).put("k", color)
        .put("f", folder).put("p", pinned).put("d", deleted).put("u", updated)
}

private fun JSONObject.toNote(): Note {
    val a = getJSONArray("l")
    val ls = List(a.length()) { i ->
        a.getJSONObject(i).let { Line(it.optString("x"), it.optInt("c")) }
    }
    return Note(
        id = getString("id"),
        title = optString("t"),
        lines = ls.ifEmpty { listOf(Line()) },
        color = optInt("k"),
        folder = optInt("f"),
        pinned = optBoolean("p"),
        deleted = optBoolean("d"),
        updated = optLong("u"),
    )
}

class NotesViewModel(app: Application) : AndroidViewModel(app) {
    private val prefs = app.getSharedPreferences("notas", Context.MODE_PRIVATE)
    private val handler = Handler(Looper.getMainLooper())
    private val writer = Runnable { write() }

    val notes = mutableStateListOf<Note>()

    init {
        runCatching {
            val a = JSONArray(prefs.getString("notes", null) ?: "[]")
            for (i in 0 until a.length()) notes.add(a.getJSONObject(i).toNote())
        }
    }

    fun get(id: String): Note? = notes.firstOrNull { it.id == id }

    fun create(folder: Int): String {
        val n = Note(folder = folder)
        notes.add(n)
        return n.id
    }

    fun update(n: Note) {
        val i = notes.indexOfFirst { it.id == n.id }
        if (i >= 0) {
            notes[i] = n.copy(updated = System.currentTimeMillis())
            schedule()
        }
    }

    fun deleteForever(id: String) {
        notes.removeAll { it.id == id }
        schedule()
    }

    fun flush() {
        handler.removeCallbacks(writer)
        write()
    }

    private fun schedule() {
        handler.removeCallbacks(writer)
        handler.postDelayed(writer, 300)
    }

    private fun write() {
        val a = JSONArray()
        notes.forEach { a.put(it.toJson()) }
        prefs.edit().putString("notes", a.toString()).apply()
    }
}
