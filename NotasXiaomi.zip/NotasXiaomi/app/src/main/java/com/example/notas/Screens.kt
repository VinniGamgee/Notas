package com.example.notas

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.staggeredgrid.LazyStaggeredGridState
import androidx.compose.foundation.lazy.staggeredgrid.LazyVerticalStaggeredGrid
import androidx.compose.foundation.lazy.staggeredgrid.StaggeredGridCells
import androidx.compose.foundation.lazy.staggeredgrid.StaggeredGridItemSpan
import androidx.compose.foundation.lazy.staggeredgrid.items
import androidx.compose.foundation.lazy.staggeredgrid.rememberLazyStaggeredGridState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.time.temporal.ChronoUnit
import java.util.Locale

fun formatDate(ms: Long): String {
    val zone = ZoneId.systemDefault()
    val dt = Instant.ofEpochMilli(ms).atZone(zone)
    val days = ChronoUnit.DAYS.between(dt.toLocalDate(), LocalDate.now(zone))
    val hm = dt.format(DateTimeFormatter.ofPattern("HH:mm"))
    return when {
        days <= 0L -> "Hoje $hm"
        days == 1L -> "Ontem $hm"
        else -> dt.format(DateTimeFormatter.ofPattern("d MMM", Locale.forLanguageTag("pt-BR")))
    }
}

@Composable
fun NotasApp(vm: NotesViewModel) {
    var openId by rememberSaveable { mutableStateOf<String?>(null) }
    var isNew by rememberSaveable { mutableStateOf(false) }
    var folder by rememberSaveable { mutableStateOf(-1) }
    val grid = rememberLazyStaggeredGridState()

    Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        val id = openId
        if (id == null) {
            ListScreen(
                vm = vm,
                folder = folder,
                onFolder = { folder = it },
                grid = grid,
                onOpen = { openId = it; isNew = false },
                onNew = {
                    openId = vm.create(if (folder > 0) folder else 0)
                    isNew = true
                },
            )
        } else {
            EditorScreen(vm, id, isNew) { openId = null }
        }
    }
}

// ───────────────────────── Lista ─────────────────────────

@Composable
fun ListScreen(
    vm: NotesViewModel,
    folder: Int,
    onFolder: (Int) -> Unit,
    grid: LazyStaggeredGridState,
    onOpen: (String) -> Unit,
    onNew: () -> Unit,
) {
    var query by rememberSaveable { mutableStateOf("") }
    val trash = folder == -2
    val total = vm.notes.count { !it.deleted }
    val q = query.trim()
    val shown = vm.notes
        .filter { n ->
            n.deleted == trash &&
                (folder < 0 || n.folder == folder) &&
                (q.isEmpty() ||
                    (n.title + " " + n.lines.joinToString(" ") { it.text }).contains(q, ignoreCase = true))
        }
        .sortedWith(compareByDescending<Note> { it.pinned }.thenByDescending { it.updated })
    val muted = MaterialTheme.colorScheme.onSurfaceVariant

    Box(Modifier.fillMaxSize().systemBarsPadding()) {
        LazyVerticalStaggeredGrid(
            columns = StaggeredGridCells.Fixed(2),
            state = grid,
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 110.dp),
            verticalItemSpacing = 10.dp,
            horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            item(span = StaggeredGridItemSpan.FullLine) {
                Header(total, query, { query = it }, folder, onFolder)
            }
            if (shown.isEmpty()) {
                item(span = StaggeredGridItemSpan.FullLine) {
                    Text(
                        text = when {
                            trash -> "A lixeira está vazia"
                            q.isNotEmpty() -> "Nada encontrado"
                            else -> "Toque em + para criar sua primeira nota"
                        },
                        color = muted,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth().padding(top = 60.dp),
                    )
                }
            }
            items(shown, key = { it.id }) { n ->
                NoteCard(n) { onOpen(n.id) }
            }
        }
        if (!trash) {
            FloatingActionButton(
                onClick = onNew,
                shape = CircleShape,
                containerColor = Orange,
                contentColor = Color.White,
                modifier = Modifier.align(Alignment.BottomEnd).padding(20.dp),
            ) {
                Icon(Icons.Default.Add, contentDescription = "Nova nota")
            }
        }
    }
}

@Composable
private fun Header(
    total: Int,
    query: String,
    onQuery: (String) -> Unit,
    folder: Int,
    onFolder: (Int) -> Unit,
) {
    val fg = MaterialTheme.colorScheme.onBackground
    val muted = MaterialTheme.colorScheme.onSurfaceVariant
    val chip = MaterialTheme.colorScheme.surfaceVariant

    Column(Modifier.fillMaxWidth()) {
        Text(
            "Notas",
            fontSize = 34.sp,
            fontWeight = FontWeight.Bold,
            color = fg,
            modifier = Modifier.padding(start = 4.dp, top = 16.dp),
        )
        Text(
            "$total " + if (total == 1) "nota" else "notas",
            fontSize = 14.sp,
            color = muted,
            modifier = Modifier.padding(start = 4.dp, bottom = 14.dp),
        )
        Row(
            Modifier
                .fillMaxWidth()
                .height(44.dp)
                .clip(RoundedCornerShape(22.dp))
                .background(chip)
                .padding(horizontal = 14.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(Icons.Default.Search, contentDescription = null, tint = muted, modifier = Modifier.size(20.dp))
            Spacer(Modifier.width(8.dp))
            Box(Modifier.weight(1f)) {
                if (query.isEmpty()) Text("Pesquisar nas notas", color = muted)
                BasicTextField(
                    value = query,
                    onValueChange = onQuery,
                    singleLine = true,
                    textStyle = TextStyle(color = fg, fontSize = 16.sp),
                    cursorBrush = SolidColor(Orange),
                    modifier = Modifier.fillMaxWidth(),
                )
            }
        }
        Row(
            Modifier.horizontalScroll(rememberScrollState()).padding(vertical = 14.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            listOf(-1 to "Todas", 1 to FOLDERS[1], 2 to FOLDERS[2], 3 to FOLDERS[3], -2 to "Lixeira")
                .forEach { (k, label) ->
                    val on = k == folder
                    Text(
                        label,
                        fontSize = 14.sp,
                        fontWeight = if (on) FontWeight.SemiBold else FontWeight.Normal,
                        color = if (on) Color.White else fg,
                        modifier = Modifier
                            .clip(RoundedCornerShape(18.dp))
                            .background(if (on) Orange else chip)
                            .clickable { onFolder(k) }
                            .padding(horizontal = 15.dp, vertical = 7.dp),
                    )
                }
        }
    }
}

@Composable
private fun NoteCard(n: Note, onClick: () -> Unit) {
    val fg = MaterialTheme.colorScheme.onBackground
    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(noteColor(n.color))
            .clickable(onClick = onClick)
            .padding(14.dp),
    ) {
        if (n.title.isNotBlank() || n.pinned) {
            Row(verticalAlignment = Alignment.Top) {
                Text(
                    n.title,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 16.sp,
                    color = fg,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f),
                )
                if (n.pinned) Text("📌", fontSize = 12.sp)
            }
            Spacer(Modifier.height(4.dp))
        }
        n.lines.filter { it.text.isNotBlank() }.take(6).forEach { l ->
            val prefix = when (l.check) {
                2 -> "☑ "
                1 -> "☐ "
                else -> ""
            }
            Text(
                prefix + l.text,
                fontSize = 14.sp,
                color = fg.copy(alpha = if (l.check == 2) 0.5f else 0.75f),
                textDecoration = if (l.check == 2) TextDecoration.LineThrough else null,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
            )
        }
        Spacer(Modifier.height(8.dp))
        Text(formatDate(n.updated), fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

// ───────────────────────── Editor ─────────────────────────

@Composable
fun EditorScreen(vm: NotesViewModel, id: String, isNew: Boolean, onClose: () -> Unit) {
    val note = vm.get(id)
    if (note == null) {
        LaunchedEffect(Unit) { onClose() }
        return
    }
    val ro = note.deleted
    val fg = MaterialTheme.colorScheme.onBackground
    val muted = MaterialTheme.colorScheme.onSurfaceVariant
    val chip = MaterialTheme.colorScheme.surfaceVariant
    var focusLine by remember { mutableStateOf(-1) }
    var cur by remember { mutableStateOf(0) }
    var menu by remember { mutableStateOf(false) }
    val titleFocus = remember { FocusRequester() }

    fun edit(f: (Note) -> Note) {
        vm.get(id)?.let { vm.update(f(it)) }
    }

    fun close() {
        vm.get(id)?.let {
            if (!it.deleted && it.title.isBlank() && it.lines.all { l -> l.text.isBlank() }) vm.deleteForever(id)
        }
        onClose()
    }

    fun setCheck(i: Int, c: Int) = edit { n ->
        n.copy(lines = n.lines.mapIndexed { k, l -> if (k == i) l.copy(check = c) else l })
    }

    fun setText(i: Int, raw: String) {
        val parts = raw.replace("\r", "").split('\n')
        edit { n ->
            val l = n.lines.toMutableList()
            if (i !in l.indices) return@edit n
            val c = l[i].check
            l[i] = l[i].copy(text = parts[0])
            for (k in 1 until parts.size) l.add(i + k, Line(parts[k], if (c > 0) 1 else 0))
            n.copy(lines = l)
        }
        if (parts.size > 1) focusLine = i + parts.size - 1
    }

    fun enter(i: Int) {
        val l0 = vm.get(id)?.lines?.getOrNull(i) ?: return
        if (l0.check > 0 && l0.text.isEmpty()) {
            setCheck(i, 0)
            focusLine = i
        } else {
            edit { n ->
                n.copy(lines = n.lines.toMutableList().apply { add(i + 1, Line("", if (l0.check > 0) 1 else 0)) })
            }
            focusLine = i + 1
        }
    }

    fun backspace(i: Int) {
        val l0 = vm.get(id)?.lines?.getOrNull(i) ?: return
        if (l0.check > 0) {
            setCheck(i, 0)
            return
        }
        if (i > 0) {
            edit { n -> n.copy(lines = n.lines.filterIndexed { k, _ -> k != i }) }
            focusLine = i - 1
        }
    }

    fun toggleCheck() {
        val ls = vm.get(id)?.lines ?: return
        val i = cur.coerceIn(0, ls.lastIndex)
        setCheck(i, if (ls[i].check > 0) 0 else 1)
        focusLine = i
    }

    BackHandler { close() }
    LaunchedEffect(Unit) { if (isNew) titleFocus.requestFocus() }

    Column(
        Modifier
            .fillMaxSize()
            .background(noteColor(note.color))
            .systemBarsPadding()
            .imePadding(),
    ) {
        // Barra superior
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            IconButton(onClick = { close() }) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Voltar", tint = fg)
            }
            Spacer(Modifier.weight(1f))
            if (ro) {
                IconButton(onClick = {
                    edit { it.copy(deleted = false) }
                    close()
                }) {
                    Icon(Icons.Default.Refresh, contentDescription = "Restaurar", tint = fg)
                }
            } else {
                IconButton(onClick = { edit { it.copy(pinned = !it.pinned) } }) {
                    Text("📌", fontSize = 20.sp, modifier = Modifier.alpha(if (note.pinned) 1f else 0.35f))
                }
            }
            IconButton(onClick = {
                if (ro) vm.deleteForever(id) else edit { it.copy(deleted = true, pinned = false) }
                onClose()
            }) {
                Icon(
                    Icons.Default.Delete,
                    contentDescription = if (ro) "Excluir definitivamente" else "Mover para a lixeira",
                    tint = fg,
                )
            }
        }

        // Conteúdo
        Column(
            Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp),
        ) {
            BasicTextField(
                value = note.title,
                onValueChange = { v -> edit { it.copy(title = v) } },
                readOnly = ro,
                singleLine = true,
                textStyle = TextStyle(color = fg, fontSize = 26.sp, fontWeight = FontWeight.Bold),
                cursorBrush = SolidColor(Orange),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
                keyboardActions = KeyboardActions(onNext = { focusLine = 0 }),
                decorationBox = { inner ->
                    Box {
                        if (note.title.isEmpty()) {
                            Text(
                                "Título",
                                fontSize = 26.sp,
                                fontWeight = FontWeight.Bold,
                                color = muted.copy(alpha = 0.6f),
                            )
                        }
                        inner()
                    }
                },
                modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp).focusRequester(titleFocus),
            )
            val chars = note.title.length + note.lines.sumOf { it.text.length }
            Text(
                "${formatDate(note.updated)} | $chars caracteres",
                fontSize = 12.sp,
                color = muted,
                modifier = Modifier.padding(bottom = 10.dp),
            )
            note.lines.forEachIndexed { i, line ->
                LineRow(
                    line = line,
                    first = i == 0,
                    readOnly = ro,
                    focus = focusLine == i,
                    onFocused = { cur = i },
                    onFocusDone = { focusLine = -1 },
                    onText = { setText(i, it) },
                    onCheck = { setCheck(i, it) },
                    onEnter = { enter(i) },
                    onBackspace = { backspace(i) },
                )
            }
            Spacer(
                Modifier
                    .fillMaxWidth()
                    .height(240.dp)
                    .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {
                        if (!ro) focusLine = note.lines.lastIndex
                    },
            )
        }

        // Barra inferior
        if (!ro) {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                IconButton(onClick = { toggleCheck() }) {
                    Icon(Icons.Default.Check, contentDescription = "Lista de tarefas", tint = fg)
                }
                Spacer(Modifier.weight(1f))
                for (k in 0..5) {
                    val sel = k == note.color
                    Box(
                        Modifier
                            .padding(horizontal = 5.dp)
                            .size(26.dp)
                            .clip(CircleShape)
                            .background(noteColor(k))
                            .border(
                                if (sel) 2.dp else 1.dp,
                                if (sel) Orange else muted.copy(alpha = 0.5f),
                                CircleShape,
                            )
                            .clickable { edit { it.copy(color = k) } },
                    )
                }
                Spacer(Modifier.weight(1f))
                Box {
                    Text(
                        FOLDERS[note.folder.coerceIn(0, FOLDERS.lastIndex)],
                        fontSize = 14.sp,
                        color = fg,
                        modifier = Modifier
                            .clip(RoundedCornerShape(16.dp))
                            .background(chip)
                            .clickable { menu = true }
                            .padding(horizontal = 12.dp, vertical = 7.dp),
                    )
                    DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                        FOLDERS.forEachIndexed { k, name ->
                            DropdownMenuItem(
                                text = { Text(name) },
                                onClick = {
                                    edit { it.copy(folder = k) }
                                    menu = false
                                },
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun LineRow(
    line: Line,
    first: Boolean,
    readOnly: Boolean,
    focus: Boolean,
    onFocused: () -> Unit,
    onFocusDone: () -> Unit,
    onText: (String) -> Unit,
    onCheck: (Int) -> Unit,
    onEnter: () -> Unit,
    onBackspace: () -> Unit,
) {
    val fg = MaterialTheme.colorScheme.onBackground
    val muted = MaterialTheme.colorScheme.onSurfaceVariant
    val fr = remember { FocusRequester() }
    val done = line.check == 2

    LaunchedEffect(focus) {
        if (focus) {
            fr.requestFocus()
            onFocusDone()
        }
    }

    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.Top) {
        if (line.check > 0) {
            Box(
                Modifier
                    .padding(top = 6.dp, end = 10.dp)
                    .size(22.dp)
                    .clip(CircleShape)
                    .background(if (done) Orange else Color.Transparent)
                    .border(2.dp, if (done) Orange else muted, CircleShape)
                    .clickable(enabled = !readOnly) { onCheck(if (done) 1 else 2) },
                contentAlignment = Alignment.Center,
            ) {
                if (done) {
                    Icon(Icons.Default.Check, contentDescription = null, tint = Color.White, modifier = Modifier.size(14.dp))
                }
            }
        }
        BasicTextField(
            value = line.text,
            onValueChange = onText,
            readOnly = readOnly,
            textStyle = TextStyle(
                color = if (done) fg.copy(alpha = 0.5f) else fg,
                fontSize = 17.sp,
                lineHeight = 24.sp,
                textDecoration = if (done) TextDecoration.LineThrough else null,
            ),
            cursorBrush = SolidColor(Orange),
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
            keyboardActions = KeyboardActions(onNext = { onEnter() }),
            decorationBox = { inner ->
                Box {
                    if (first && line.text.isEmpty()) {
                        Text("Comece a escrever…", fontSize = 17.sp, color = muted.copy(alpha = 0.6f))
                    }
                    inner()
                }
            },
            modifier = Modifier
                .weight(1f)
                .padding(vertical = 4.dp)
                .focusRequester(fr)
                .onFocusChanged { if (it.isFocused) onFocused() }
                .onPreviewKeyEvent { e ->
                    if (e.type == KeyEventType.KeyDown && e.key == Key.Backspace && line.text.isEmpty() && !readOnly) {
                        onBackspace()
                        true
                    } else {
                        false
                    }
                },
        )
    }
}
