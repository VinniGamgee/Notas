package com.example.notas

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Orange = Color(0xFFFF9500)

private val LightNotes = listOf(
    Color(0xFFFFFFFF), Color(0xFFFFF3C4), Color(0xFFFFE0E6),
    Color(0xFFDFF3DD), Color(0xFFDCEBFF), Color(0xFFEBE1FF),
)
private val DarkNotes = listOf(
    Color(0xFF1F1F1F), Color(0xFF4A4220), Color(0xFF4D2B33),
    Color(0xFF27412B), Color(0xFF26384F), Color(0xFF3C3050),
)

@Composable
fun noteColor(i: Int): Color =
    (if (isSystemInDarkTheme()) DarkNotes else LightNotes)[i.coerceIn(0, 5)]

@Composable
fun NotasTheme(content: @Composable () -> Unit) {
    val scheme = if (isSystemInDarkTheme()) {
        darkColorScheme(
            primary = Orange,
            onPrimary = Color.White,
            background = Color(0xFF0E0E0E),
            surface = Color(0xFF0E0E0E),
            onBackground = Color(0xFFEDEDED),
            onSurface = Color(0xFFEDEDED),
            surfaceVariant = Color(0xFF2A2A2A),
            onSurfaceVariant = Color(0xFF8E8E93),
        )
    } else {
        lightColorScheme(
            primary = Orange,
            onPrimary = Color.White,
            background = Color(0xFFF6F6F6),
            surface = Color(0xFFF6F6F6),
            onBackground = Color(0xFF1A1A1A),
            onSurface = Color(0xFF1A1A1A),
            surfaceVariant = Color(0xFFE8E8E8),
            onSurfaceVariant = Color(0xFF8A8A8A),
        )
    }
    MaterialTheme(colorScheme = scheme, content = content)
}

class MainActivity : ComponentActivity() {
    private val vm: NotesViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            NotasTheme {
                NotasApp(vm)
            }
        }
    }

    override fun onStop() {
        vm.flush()
        super.onStop()
    }
}
